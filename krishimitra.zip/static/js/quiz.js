class Quiz {
    constructor() {
        this.questions = [
            {
                question: "What is the ideal pH range for most crops?",
                options: ["4.0-5.0", "5.5-7.0", "7.5-8.5", "8.5-9.0"],
                correct: 1
            },
            {
                question: "Which nutrient is primarily responsible for leaf growth?",
                options: ["Phosphorus", "Potassium", "Nitrogen", "Calcium"],
                correct: 2
            },
            {
                question: "What is crop rotation primarily used for?",
                options: ["Increasing yield", "Pest control", "Water conservation", "All of the above"],
                correct: 3
            },
            {
                question: "Which season is best for Rabi crops in India?",
                options: ["June-September", "October-March", "April-June", "July-October"],
                correct: 1
            },
            {
                question: "What is the purpose of green manure?",
                options: ["Weed control", "Soil enrichment", "Pest management", "Water retention"],
                correct: 1
            },
            {
                question: "Which irrigation method is most water-efficient?",
                options: ["Flood irrigation", "Sprinkler irrigation", "Drip irrigation", "Furrow irrigation"],
                correct: 2
            },
            {
                question: "What does NPK stand for in fertilizers?",
                options: ["Nitrogen, Phosphorus, Potassium", "Nitrogen, Potassium, Calcium", "Nitrogen, Phosphorus, Carbon", "Nitrogen, Potassium, Carbon"],
                correct: 0
            },
            {
                question: "Which crop is known as 'Golden Fiber'?",
                options: ["Wheat", "Rice", "Jute", "Cotton"],
                correct: 2
            },
            {
                question: "What is the main symptom of nitrogen deficiency in plants?",
                options: ["Purple leaves", "Yellowing of older leaves", "Brown spots", "Stunted growth"],
                correct: 1
            },
            {
                question: "Which practice helps in soil conservation?",
                options: ["Overgrazing", "Deforestation", "Terrace farming", "Monocropping"],
                correct: 2
            },
            {
                question: "What is the optimal temperature for wheat cultivation?",
                options: ["10-15°C", "15-20°C", "20-25°C", "25-30°C"],
                correct: 2
            },
            {
                question: "Which microorganism helps in nitrogen fixation?",
                options: ["Rhizobium", "E. coli", "Lactobacillus", "Yeast"],
                correct: 0
            },
            {
                question: "What is the primary purpose of pruning?",
                options: ["Increase plant height", "Remove dead branches", "Reduce fruit quality", "Increase water usage"],
                correct: 1
            },
            {
                question: "Which pesticide is derived from neem tree?",
                options: ["Azadirachtin", "Pyrethrin", "Rotenone", "Nicotine"],
                correct: 0
            },
            {
                question: "What is the main advantage of organic farming?",
                options: ["Higher cost", "Environmental sustainability", "Lower yield", "More labor intensive"],
                correct: 1
            }
        ];
        
        this.currentQuestionIndex = 0;
        this.score = 0;
        this.userAnswers = [];
        this.quizQuestions = [];
        this.timer = null;
        this.timeElapsed = 0;
        
        this.initializeQuiz();
    }
    
    initializeQuiz() {
        this.shuffleQuestions();
        document.getElementById('startQuiz').addEventListener('click', () => this.startQuiz());
        document.getElementById('nextBtn').addEventListener('click', () => this.nextQuestion());
        document.getElementById('prevBtn').addEventListener('click', () => this.previousQuestion());
        document.getElementById('submitQuiz').addEventListener('click', () => this.submitQuiz());
        document.getElementById('retryQuiz').addEventListener('click', () => this.retryQuiz());
    }
    
    shuffleQuestions() {
        // Shuffle and select 10 random questions
        const shuffled = [...this.questions].sort(() => 0.5 - Math.random());
        this.quizQuestions = shuffled.slice(0, 10);
    }
    
    startQuiz() {
        document.getElementById('quizIntro').style.display = 'none';
        document.getElementById('quizContent').style.display = 'block';
        this.startTimer();
        this.showQuestion(0);
    }
    
    startTimer() {
        this.timer = setInterval(() => {
            this.timeElapsed++;
            this.updateTimerDisplay();
        }, 1000);
    }
    
    updateTimerDisplay() {
        const minutes = Math.floor(this.timeElapsed / 60);
        const seconds = this.timeElapsed % 60;
        document.getElementById('timer').textContent = 
            `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    }
    
    showQuestion(index) {
        this.currentQuestionIndex = index;
        const question = this.quizQuestions[index];
        
        document.getElementById('questionText').textContent = question.question;
        document.getElementById('progressText').textContent = 
            `Question ${index + 1} of ${this.quizQuestions.length}`;
        
        // Update progress bar
        const progress = ((index + 1) / this.quizQuestions.length) * 100;
        document.getElementById('progressFill').style.width = `${progress}%`;
        
        // Display options
        const optionsContainer = document.getElementById('optionsContainer');
        optionsContainer.innerHTML = '';
        
        question.options.forEach((option, optionIndex) => {
            const optionElement = document.createElement('div');
            optionElement.className = 'option';
            if (this.userAnswers[index] === optionIndex) {
                optionElement.classList.add('selected');
            }
            optionElement.textContent = option;
            optionElement.addEventListener('click', () => this.selectOption(optionIndex));
            optionsContainer.appendChild(optionElement);
        });
        
        // Update navigation buttons
        document.getElementById('prevBtn').disabled = index === 0;
        
        if (index === this.quizQuestions.length - 1) {
            document.getElementById('nextBtn').style.display = 'none';
            document.getElementById('submitQuiz').style.display = 'inline-block';
        } else {
            document.getElementById('nextBtn').style.display = 'inline-block';
            document.getElementById('submitQuiz').style.display = 'none';
        }
    }
    
    selectOption(optionIndex) {
        this.userAnswers[this.currentQuestionIndex] = optionIndex;
        
        // Update UI
        const options = document.querySelectorAll('.option');
        options.forEach((option, index) => {
            option.classList.toggle('selected', index === optionIndex);
        });
    }
    
    nextQuestion() {
        if (this.currentQuestionIndex < this.quizQuestions.length - 1) {
            this.showQuestion(this.currentQuestionIndex + 1);
        }
    }
    
    previousQuestion() {
        if (this.currentQuestionIndex > 0) {
            this.showQuestion(this.currentQuestionIndex - 1);
        }
    }
    
    submitQuiz() {
        clearInterval(this.timer);
        this.calculateScore();
        this.showResults();
    }
    
    calculateScore() {
        this.score = 0;
        this.quizQuestions.forEach((question, index) => {
            if (this.userAnswers[index] === question.correct) {
                this.score++;
            }
        });
    }
    
    showResults() {
        document.getElementById('quizContent').style.display = 'none';
        document.getElementById('quizResult').style.display = 'block';
        
        const percentage = (this.score / this.quizQuestions.length) * 100;
        document.getElementById('scorePercentage').textContent = `${percentage.toFixed(1)}%`;
        document.getElementById('finalScore').textContent = `${this.score}/${this.quizQuestions.length}`;
        
        // Update progress circle
        const scoreCircle = document.querySelector('.score-circle');
        scoreCircle.style.background = `conic-gradient(var(--primary-color) ${percentage}%, var(--border-color) ${percentage}%)`;
        
        // Performance text
        const performanceText = document.getElementById('performanceText');
        if (percentage >= 80) {
            performanceText.textContent = 'Excellent! You have great farming knowledge!';
            performanceText.style.color = 'var(--primary-color)';
        } else if (percentage >= 60) {
            performanceText.textContent = 'Good! You have solid farming knowledge.';
            performanceText.style.color = 'var(--secondary-color)';
        } else {
            performanceText.textContent = 'Keep learning! Review the farming basics.';
            performanceText.style.color = '#ff6b6b';
        }
    }
    
    retryQuiz() {
        this.currentQuestionIndex = 0;
        this.score = 0;
        this.userAnswers = [];
        this.timeElapsed = 0;
        this.shuffleQuestions();
        
        document.getElementById('quizResult').style.display = 'none';
        document.getElementById('quizIntro').style.display = 'block';
        
        document.getElementById('timer').textContent = '--:--';
    }
}

// Initialize quiz when page loads
document.addEventListener('DOMContentLoaded', () => {
    new Quiz();
});