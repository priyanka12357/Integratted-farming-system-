const GEMINI_API_KEY = 'your_gemini_api_key_here';
const API_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${GEMINI_API_KEY}`;

class Chatbot {
    constructor() {
        this.messages = [
            {
                role: 'model',
                parts: [{ text: 'Hello! I\'m Krishimitra AI, your farming assistant. How can I help you with your agricultural queries today?' }]
            }
        ];
        this.isListening = false;
        this.recognition = null;
        this.initializeEventListeners();
        this.updateChatDisplay();
        this.initializeSpeechRecognition();
    }

    initializeEventListeners() {
        const sendButton = document.getElementById('sendButton');
        const userInput = document.getElementById('userInput');
        const suggestionChips = document.querySelectorAll('.suggestion-chip');
        const voiceButton = document.getElementById('voiceButton');

        sendButton.addEventListener('click', () => this.sendMessage());
        userInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                this.sendMessage();
            }
        });

        suggestionChips.forEach(chip => {
            chip.addEventListener('click', () => {
                const question = chip.getAttribute('data-question');
                userInput.value = question;
                this.sendMessage();
            });
        });

        if (voiceButton) {
            voiceButton.addEventListener('click', () => this.toggleVoiceInput());
        }
    }

    initializeSpeechRecognition() {
        // Check if browser supports speech recognition
        if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
            const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            this.recognition = new SpeechRecognition();
            
            this.recognition.continuous = false;
            this.recognition.interimResults = true;
            this.recognition.lang = 'en-US';
            this.recognition.maxAlternatives = 1;

            this.recognition.onstart = () => {
                this.isListening = true;
                this.updateVoiceButton();
                this.showListeningIndicator();
            };

            this.recognition.onresult = (event) => {
                const transcript = Array.from(event.results)
                    .map(result => result[0])
                    .map(result => result.transcript)
                    .join('');

                document.getElementById('userInput').value = transcript;
                
                // If final result, send message automatically
                if (event.results[0].isFinal) {
                    this.hideListeningIndicator();
                    setTimeout(() => {
                        this.sendMessage();
                    }, 500);
                }
            };

            this.recognition.onerror = (event) => {
                console.error('Speech recognition error:', event.error);
                this.isListening = false;
                this.updateVoiceButton();
                this.hideListeningIndicator();
                
                if (event.error === 'not-allowed') {
                    this.showVoiceError('Microphone access denied. Please allow microphone permissions.');
                } else {
                    this.showVoiceError('Voice input failed. Please try again.');
                }
            };

            this.recognition.onend = () => {
                this.isListening = false;
                this.updateVoiceButton();
                this.hideListeningIndicator();
            };
        } else {
            console.warn('Speech recognition not supported in this browser');
            this.showVoiceNotSupported();
        }
    }

    toggleVoiceInput() {
        if (!this.recognition) {
            this.showVoiceNotSupported();
            return;
        }

        if (this.isListening) {
            this.recognition.stop();
        } else {
            try {
                this.recognition.start();
            } catch (error) {
                console.error('Error starting speech recognition:', error);
                this.showVoiceError('Failed to start voice input. Please check microphone permissions.');
            }
        }
    }

    updateVoiceButton() {
        const voiceButton = document.getElementById('voiceButton');
        if (voiceButton) {
            if (this.isListening) {
                voiceButton.innerHTML = '<i class="fas fa-microphone-slash"></i>';
                voiceButton.classList.add('listening');
            } else {
                voiceButton.innerHTML = '<i class="fas fa-microphone"></i>';
                voiceButton.classList.remove('listening');
            }
        }
    }

    showListeningIndicator() {
        let indicator = document.getElementById('listeningIndicator');
        if (!indicator) {
            indicator = document.createElement('div');
            indicator.id = 'listeningIndicator';
            indicator.className = 'listening-indicator';
            indicator.innerHTML = `
                <div class="listening-content">
                    <div class="listening-animation">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                    <p>Listening... Speak now</p>
                </div>
            `;
            document.querySelector('.chatbot-container').appendChild(indicator);
        }
        indicator.style.display = 'flex';
    }

    hideListeningIndicator() {
        const indicator = document.getElementById('listeningIndicator');
        if (indicator) {
            indicator.style.display = 'none';
        }
    }

    showVoiceError(message) {
        this.addMessage('assistant', `🎤 Voice Input Error: ${message}`);
    }

    showVoiceNotSupported() {
        this.addMessage('assistant', '🎤 Voice input is not supported in your browser. Please use Chrome, Edge, or Safari for voice features.');
    }

    async sendMessage() {
        const userInput = document.getElementById('userInput');
        const message = userInput.value.trim();

        if (!message) return;

        // Add user message to chat
        this.addMessage('user', message);
        userInput.value = '';

        // Show typing indicator
        this.showTypingIndicator();

        try {
            const response = await this.getAIResponse(message);
            this.removeTypingIndicator();
            this.addMessage('assistant', response);
            
            // Optional: Speak the response
            if (this.isSpeechEnabled()) {
                this.speakResponse(response);
            }
        } catch (error) {
            this.removeTypingIndicator();
            this.addMessage('assistant', 'I apologize, but I\'m having trouble connecting right now. Please try again later.');
            console.error('Chatbot error:', error);
        }
    }

    async getAIResponse(userMessage) {
        try {
            // For demo purposes, using mock responses when API key is not set
            if (GEMINI_API_KEY === 'your_gemini_api_key_here') {
                return this.getMockResponse(userMessage);
            }

            const response = await fetch(API_URL, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    contents: [
                        {
                            parts: [
                                { 
                                    text: `You are Krishimitra AI, a helpful farming assistant specialized in agriculture. 
                                    Provide accurate, practical agricultural advice. Keep responses concise and focused on farming, crops, pests, and agricultural techniques.
                                    Be specific and helpful. If you don't know something, admit it and suggest consulting local experts.
                                    
                                    Current conversation context: ${this.getConversationContext()}
                                    
                                    User's question: ${userMessage}`
                                }
                            ]
                        }
                    ],
                    generationConfig: {
                        temperature: 0.7,
                        maxOutputTokens: 500,
                        topP: 0.8,
                        topK: 40
                    },
                    safetySettings: [
                        {
                            category: "HARM_CATEGORY_HARASSMENT",
                            threshold: "BLOCK_MEDIUM_AND_ABOVE"
                        },
                        {
                            category: "HARM_CATEGORY_HATE_SPEECH",
                            threshold: "BLOCK_MEDIUM_AND_ABOVE"
                        }
                    ]
                })
            });

            if (!response.ok) {
                throw new Error(`API request failed with status ${response.status}`);
            }

            const data = await response.json();
            
            if (data.candidates && data.candidates[0] && data.candidates[0].content) {
                return data.candidates[0].content.parts[0].text;
            } else {
                throw new Error('Invalid response format from API');
            }

        } catch (error) {
            console.error('Gemini API error:', error);
            // Fallback to mock responses
            return this.getMockResponse(userMessage);
        }
    }

    getMockResponse(userMessage) {
        const mockResponses = {
            'How to control aphids in wheat?': 'For aphid control in wheat, you can:\n\n1. **Neem Oil Spray**: Use 2-3% neem oil solution weekly\n2. **Natural Predators**: Introduce ladybugs and lacewings\n3. **Insecticidal Soap**: Apply every 5-7 days during infestation\n4. **Crop Rotation**: Rotate with non-host crops like legumes\n5. **Resistant Varieties**: Use aphid-resistant wheat varieties\n6. **Early Detection**: Monitor crops regularly for early signs',
            
            'Best time to plant rice?': 'The optimal time for rice planting varies by region:\n\n**Tropical Regions**:\n• Main season: June-July (with monsoon onset)\n• Second crop: November-December\n\n**Temperate Regions**:\n• Spring planting: April-May\n• Ensure soil temperature > 20°C\n\n**Key Guidelines**:\n• Transplant seedlings at 25-35 days old\n• Ensure adequate water availability\n• Avoid extreme temperatures during flowering',
            
            'Organic farming methods': '**Key Organic Farming Practices**:\n\n🌱 **Soil Management**:\n• Crop rotation and cover crops\n• Green manure (sunhemp, dhaincha)\n• Compost and vermicompost\n\n🐞 **Pest Control**:\n• Biological control (ladybugs, trichogramma)\n• Botanical pesticides (neem, garlic)\n• Trap crops and intercropping\n\n💧 **Water Management**:\n• Drip irrigation\n• Rainwater harvesting\n• Mulching for moisture retention\n\n🌾 **Weed Management**:\n• Manual weeding\n• Mulching\n• Soil solarization',
            
            'Water requirements for maize': '**Maize Water Requirements**:\n\n💧 **Growth Stage Water Needs**:\n• **Germination**: Light, frequent irrigation\n• **Vegetative**: 25-30mm per week\n• **Flowering**: Critical period - 35-40mm per week\n• **Grain Filling**: 25-30mm per week\n\n📊 **Total Requirement**:\n• 500-800mm per crop cycle\n• Varies by climate and soil type\n\n🚰 **Irrigation Tips**:\n• Avoid water stress during flowering\n• Use drip irrigation for efficiency\n• Monitor soil moisture regularly'
        };

        // Return mock response or default
        return mockResponses[userMessage] || `Thank you for your question about "${userMessage}". 

As a farming assistant, I recommend:

🔍 **Consult Local Experts**: Contact your local agriculture extension office for region-specific advice
📚 **Soil Testing**: Get your soil tested for precise recommendations
🌦️ **Consider Local Conditions**: Climate, soil type, and water availability greatly affect farming practices

For detailed guidance, please provide more specific information about your location, soil type, and current farming practices.`;
    }

    getConversationContext() {
        // Get last few messages for context
        const recentMessages = this.messages.slice(-4);
        return recentMessages.map(msg => {
            const role = msg.role === 'user' ? 'User' : 'Assistant';
            const content = msg.parts ? msg.parts[0].text : msg.content;
            return `${role}: ${content}`;
        }).join('\n');
    }

    addMessage(role, content) {
        if (role === 'user') {
            this.messages.push({
                role: 'user',
                parts: [{ text: content }]
            });
        } else {
            this.messages.push({
                role: 'model',
                parts: [{ text: content }]
            });
        }
        this.updateChatDisplay();
    }

    updateChatDisplay() {
        const chatMessages = document.getElementById('chatMessages');
        chatMessages.innerHTML = '';

        this.messages.forEach(message => {
            const messageElement = document.createElement('div');
            const role = message.role === 'user' ? 'user' : 'bot';
            const content = message.parts ? message.parts[0].text : message.content;
            
            messageElement.className = `message ${role}-message`;
            
            messageElement.innerHTML = `
                <div class="message-content">
                    <p>${this.formatMessage(content)}</p>
                </div>
                <div class="message-time">${this.getCurrentTime()}</div>
            `;

            chatMessages.appendChild(messageElement);
        });

        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    formatMessage(content) {
        // Convert markdown-style formatting to HTML
        return content
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/g, '<em>$1</em>')
            .replace(/\n/g, '<br>')
            .replace(/•\s*(.*?)(?=\n|$)/g, '• $1<br>')
            .replace(/(\d+)\.\s*(.*?)(?=\n|$)/g, '$1. $2<br>');
    }

    showTypingIndicator() {
        const chatMessages = document.getElementById('chatMessages');
        const typingElement = document.createElement('div');
        typingElement.className = 'message bot-message typing-indicator';
        typingElement.id = 'typingIndicator';
        typingElement.innerHTML = `
            <div class="message-content">
                <div class="typing-dots">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
        `;
        chatMessages.appendChild(typingElement);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    removeTypingIndicator() {
        const typingIndicator = document.getElementById('typingIndicator');
        if (typingIndicator) {
            typingIndicator.remove();
        }
    }

    isSpeechEnabled() {
        return 'speechSynthesis' in window;
    }

    speakResponse(text) {
        if (!this.isSpeechEnabled()) return;

        // Clean text for speech (remove markdown, emojis, etc.)
        const cleanText = text
            .replace(/\*\*(.*?)\*\*/g, '$1')
            .replace(/\*(.*?)\*/g, '$1')
            .replace(/[🔍📚🌦️🌱🐞💧🌾🚰📊]/g, '')
            .replace(/\n/g, '. ')
            .trim();

        const utterance = new SpeechSynthesisUtterance(cleanText);
        utterance.rate = 0.9;
        utterance.pitch = 1;
        utterance.volume = 0.8;

        // Stop any previous speech
        window.speechSynthesis.cancel();
        window.speechSynthesis.speak(utterance);
    }

    getCurrentTime() {
        const now = new Date();
        return now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }
}

// Initialize chatbot when page loads
document.addEventListener('DOMContentLoaded', () => {
    new Chatbot();
});